from plugify.plugin import Plugin

class ExamplePlugin(Plugin):
	def plugin_start(self):
		print('ExamplePlugin::plugin_start')

	def plugin_end(self):
		print('ExamplePlugin::plugin_end')
