from plugify.plugin import Plugin, PluginInfo

__plugin__ = PluginInfo('ExamplePlugin')

class ExamplePlugin(Plugin):
	def plugin_start(self):
		print('ExamplePlugin::plugin_start')

	def plugin_end(self):
		print('ExamplePlugin::plugin_end')
