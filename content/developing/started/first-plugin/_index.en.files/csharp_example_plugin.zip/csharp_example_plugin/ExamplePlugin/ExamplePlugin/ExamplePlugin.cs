﻿using System;
using System.IO;
using Plugify;

namespace ExamplePlugin
{
    public class SamplePlugin : Plugin
    {
        void OnStart()
        {
            Console.Write($"{Name}: OnStart\n");
        }

        void OnEnd()
        {
            Console.Write($"{Name}: OnEnd\n");
        }
    }
}